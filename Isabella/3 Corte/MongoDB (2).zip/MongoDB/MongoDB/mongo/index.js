//conexión a BD
const express=require('express');
const mongoose=require('mongoose');

const app=express();
const PORT=3000;

//crear el cuerpo de las peticiones (middleware)
app.use(express.json());

// conexión BD
mongoose.connect('mongodb://localhost:27017/Prueba',{
    useNewURLParser:true,
    useUnifiedTopology:true,
}).then(()=>console.log('Se conectó a Mongo'))
.catch(err=>console.error('No se conectó a BD error: ',err));

// iniciar el servidor
app.listen(PORT,()=>{
    console.log('Servidor ejecutándose sobre el puerto:',PORT);
});

//agregar las rutas para manipular user
const user=require('./user/User');

//registrar un usuario nuevo - las rutas siempre deben ser en minusculas
app.post('/users', async(req,res)=>{
    try{
        const user=new User(req.body);
        await user.save();
        res.status(201).send(user);
    }catch(error){
        res.status(400).send(error)
    }
})

//consultar los usuarios
app.get('/users', async(req,res)=>{
    try{
        const users= await user.find();
        res.status(201).send(users);
    }catch(error){
        res.status(500).send(error)
    }
})

//consultar un usuario por ID
app.get('/users/:id', async(req,res)=>{
    try{
        const user= await user.findById(req.params.id);
        if(!user) return response.status(404).send();
        res.status(201).send(user);
    }catch(error){
        res.status(500).send(error)
    }
})

//actualizar un usuario por ID
app.get('/users/:id', async(req,res)=>{
    try{
        const user= await user.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});
        if(!user) return response.status(404).send();
        res.status(201).send(user);
    }catch(error){
        res.status(400).send(error)
    }
})

