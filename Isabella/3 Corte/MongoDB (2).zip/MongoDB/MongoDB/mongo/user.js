//Modelo para definir la manipulacion del modulo de usuarios, es lo que va a permitir manejar la CRU

const mongoose=require('mongoose');

const userSchema=new mongoose.Schema({
    nombre:{
        type:String,
        require:true
    },
    edad:{
        type:Number,
        require:true
    },
    email:{
        type:String,
        require:true
    },
});

module.exports=mongoose.model('user',userSchema);

