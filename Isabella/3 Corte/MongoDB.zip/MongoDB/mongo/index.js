//conexión a BD
const express=require('express');
const mongoose=require('mongoose');

const app=express();
const PORT=3000;

//crear el cuerpo de las peticiones (middleware)
app.use(express.json());

// conexión BD
mongoose.connect('mongodb://localhost:27017/BDMongo',{
    useNewURLParser:true,
    useUnifiedTopology:true,
}).then(()=>console.log('Se conectó a Mongo'))
.catch(err=>console.error('No se conectó a BD error: ',err));

// iniciar el servidor
app.listen(PORT,()=>{
    console.log('Servidor ejecutándose sobre el puerto:',PORT);
});
