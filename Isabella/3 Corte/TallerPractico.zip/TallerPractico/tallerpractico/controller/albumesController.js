import mongoose from "mongoose";
import { albumesModel } from "../model/albumesModel.js";

export const insertarAlbum = async (peticion, respuesta) => {
    try{
        let data = peticion.body
        await albumesModel.create(data)
        respuesta.status(200).send("la información del álbum se insertó correctamente")
    }catch(error){
        console.log(error);
    }
}

export const consultarAlbumes = async (peticion, respuesta) => {
    try{
        let albumes = await albumesModel.find()
        respuesta.status(200).render("index", {albumes})
    }catch(error){
        console.log(error)
    }
}

export const actualizarAlbum = async (peticion, respuesta) => {
    try{
        await albumesModel.findOneAndUpdate(
            {nombreAlbum:"El Dorado"},{$set:{anioLanzamiento:"2018"}}
        )
        respuesta.status(200).send("Se actualizó correctamente la información del álbum")
    }catch(error){
        respuesta.status(500).send("Error al actualizar los datos del album")
    }
}

export const eliminarAlbum = async (peticion, respuesta) => {
    try{
        await albumesModel.findOneAndDelete({nombreAlbum: "Abbey Road"});
        res.status(200).json(await userModel.find());
    }catch(error){
        respuesta.status(500).send("Error al eliminar el album");
    }
}