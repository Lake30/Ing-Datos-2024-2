import mongoose from "mongoose";
import { artistasModel } from "../model/artistasModel.js";

export const insertarArtista = async (peticion, respuesta) => {
    try{
        let data = peticion.body
        await artistasModel.create(data)
        respuesta.status(200).send("la información del artista se insertó correctamente")
    }catch(error){
        console.log(error);
    }
}

export const consultarArtistasporPais = async (peticion, respuesta) => {
    try{
        await artistasModel.find({paisArtista:'Estados Unidos'})
        respuesta.status(200).json(artistas)
    }catch(error){
        console.log(error);
    }
}
