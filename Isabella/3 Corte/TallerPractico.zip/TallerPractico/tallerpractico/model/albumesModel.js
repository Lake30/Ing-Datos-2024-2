import mongoose, {Schema} from "mongoose";
const albumesSchema = new Schema({
    nombreAlbum: String,
    nombreArtista: String,
    anioLanzamiento: String
})

export const albumesModel = new mongoose.model('albumes', albumesSchema)