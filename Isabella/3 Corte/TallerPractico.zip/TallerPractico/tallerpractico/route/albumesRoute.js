import { Router } from "express";
import { insertarAlbum, consultarAlbumes, actualizarAlbum, eliminarAlbum } from "../controller/albumesController.js"
const router = Router()
router.post('albumins', insertarAlbum)
router.get('albumescons', consultarAlbumes)
router.put('albumesact', actualizarAlbum)
router.delete('albumesdel', eliminarAlbum)
export default router;