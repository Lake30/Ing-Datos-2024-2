import { Router } from "express";
import { insertarArtista, consultarArtistasporPais } from "../controller/artistasController.js"
const router = Router()
router.get('/Artistasins', insertarArtista)
router.post('/Artistascons', consultarArtistasporPais)
export default router;