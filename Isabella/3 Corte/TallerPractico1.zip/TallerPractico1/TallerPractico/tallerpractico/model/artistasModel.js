import mongoose, {Schema} from "mongoose";
const artistasSchema = new Schema({
    nombreArtista: String,
    generoArtista: String,
    paisArtista: String
})

export const artistasModel = new mongoose.model('artistas', artistasSchema)
