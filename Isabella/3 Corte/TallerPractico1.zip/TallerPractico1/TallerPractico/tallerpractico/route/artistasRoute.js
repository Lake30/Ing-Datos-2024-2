import { Router } from "express";
import { insertarArtista, consultarArtistasporPais } from "../controller/artistasController.js"
const router = Router()
router.get('/artistasins', insertarArtista)
router.post('/artistascons', consultarArtistasporPais)
export default router;