import { userModel } from "../model/userModel.js";

export const obtenerDatos = async (peticion, respuesta) => {
    try {
        let usuarios = await userModel.find()
        respuesta.status(200).render("index", { usuarios })
    } catch (error) {
        console.log(error);
    }
};

export const crearDatos = async (peticion, respuesta) => {
    try {
        let data = peticion.body
        await userModel.create(data)
        let usuarios = await userModel.find()
        respuesta.status(200).render("index", {usuarios})
    } catch (error) {
        console.log(error);
    }
};

export const buscarUsuarioPorNombre = async (peticion, respuesta) => {
    try {
        const usuario = await userModel.find({name: "Ana", lastname:"López"});
        return usuario; 
    } catch (error) {
        console.log(error);
    }
};

export const buscarUsuariosde30 = async () => {
    try {
        const usuarios = await userModel.find({edad:{$gte:30}});
        return usuarios; 
    } catch (error) {
        console.log(error);
    }
};

export const modificarEdadPorNombre = async () => {
    try {
        const usuarioActualizado = await userModel.findOneAndUpdate(
            {name: "Juan", lastname: "Pérez"},
            {$set: {age: 31}}
        );
        return usuarioActualizado;
    } catch (error) {
        console.log(error);
    }
};

export const activarUsuariosMayoresA30 = async () => {
    try {
        const activacion = await userModel.updateMany(
            {age:{$gte:30} },
            {$set:{activo:true}} 
        );
        return activacion;
    } catch (error) {
        console.log(error);
    }
};

export const eliminarUsuariosMenoresDe30 = async () => {
    try {
        const resultado = await userModel.deleteMany({age:{$lt:30}});
        return resultado; 
    } catch (error) {
        console.log(error);
    }
};

export const eliminarUsuarioPorNombre = async () => {
    try {
        const resultado = await userModel.findOneAndDelete({name:"Luis", lastname:"Torres"});
    } catch (error) {
        console.log(error);
    }
};