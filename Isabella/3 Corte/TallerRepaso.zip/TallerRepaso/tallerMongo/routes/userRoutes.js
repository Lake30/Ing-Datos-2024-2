import { Router } from "express";
import { crearDatos, obtenerDatos } from "../controller/userController.js";
const router = Router()

router.get('/usuarios', obtenerDatos)
router.post('/usuarios', crearDatos)
router.get('/usuarios', buscarUsuarioPorNombre)
router.get('/usuarios', buscarUsuariosde30)
router.put('/usuarios', modificarEdadPorNombre)
router.put('/usuarios', activarUsuariosMayoresA30)
router.delete('/usuarios', eliminarUsuariosMenoresDe30)
router.delete('/usuarios', eliminarUsuarioPorNombre)

export default router;