import { productosModel } from "../model/productosModel.js";

export const obtenerProductosMayorA100 = async (peticion, respuesta) => {
    try {
        let productos = await productosModel.find({ price: { $gt: "100" } });
        respuesta.status(200).json(productos);
    } catch (error) {
        console.log(error);
    }
};

export const obtenerProductosOrdenadosDesc = async (peticion, respuesta) => {
    try {
        let productos = await productosModel.find().sort({ price: -1 });
        respuesta.status(200).json(productos);
    } catch (error) {
        console.log(error);
    }
};

export const añadirCampoEnStock = async (peticion, respuesta) => {
    try {
        await productosModel.updateMany({}, { $set: { enStock: true } });
        respuesta.status(200).send("Campo en Stock añadido a todos los productos");
    } catch (error) {
        console.log(error);
    }
};

export const actualizarStockMayorA500 = async (peticion, respuesta) => {
    try {
        await productosModel.updateMany({ price: { $gt: "500" } }, { $set: { enStock: false } });
        respuesta.status(200).send("Campo en Stock actualizado para productos con precio mayor a $500");
    } catch (error) {
        console.log(error);
    }
};

export const eliminarProductosMenorA50 = async (peticion, respuesta) => {
    try {
        await productosModel.deleteMany({ price: { $lt: "50" } });
        respuesta.status(200).send("Productos con precio menor a $50 eliminados");
    } catch (error) {
        console.log(error);
    }
};

export const obtenerPrecioPromedioPorCategoria = async (peticion, respuesta) => {
    try {
        let resultado = await productosModel.aggregate([
            {
                $group: {
                    _id: "$category",
                    precioPromedio: { $avg: "$price" }  
                }
            },
            {
                $sort: { precioPromedio: -1 }
            }
        ]);
        respuesta.status(200).json(resultado);
    } catch (error) {
        console.log(error);
    }
};

export const obtenerCategoriaConMayorPrecioPromedio = async (peticion, respuesta) => {
    try {
        let resultado = await productosModel.aggregate([
            {
                $group: {
                    _id: "$category",  
                    precioPromedio: { $avg: "$price" }  
                }
            },
            {
                $sort: { precioPromedio: -1 }  
            },
            {
                $limit: 1 
            }
        ]);
        respuesta.status(200).json(resultado);
    } catch (error) {
        console.log(error);
    }
};



