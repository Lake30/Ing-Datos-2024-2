import { userModel } from "../model/userModel.js";

export const obtenerDatos = async (peticion, respuesta) => {
    try {
        let usuarios = await userModel.find();
        respuesta.status(200).render("index", { usuarios });
    } catch (error) {
        console.log(error);
    }
};

export const crearDatos = async (peticion, respuesta) => {
    try {
        let data = peticion.body;
        await userModel.create(data);
        let usuarios = await userModel.find();
        respuesta.status(200).render("index", { usuarios });
    } catch (error) {
        console.log(error);
    }
};

export const obtenerUsuarioPorNombre = async (peticion, respuesta) => {
    try {
        let usuario = await userModel.findOne({ name: "Ana", lastname: "López" });
        respuesta.status(200).json(usuario);
    } catch (error) {
        console.log(error);
    }
};

export const obtenerUsuariosMayoresDe30 = async (peticion, respuesta) => {
    try {
        let usuarios = await userModel.find({ age: { $gte: 30 } });
        respuesta.status(200).json(usuarios);
    } catch (error) {
        console.log(error);
    }
};

export const actualizarEdadUsuario = async (peticion, respuesta) => {
    try {
        await userModel.updateOne({ name: "Juan", lastname: "Pérez" }, { $set: { age: 31 } });
        respuesta.status(200).send("Edad actualizada");
    } catch (error) {
        console.log(error);
    }
};

export const activarUsuariosMayoresDe30 = async (peticion, respuesta) => {
    try {
        await userModel.updateMany({ age: { $gte: 30 } }, { $set: { activo: true } });
        respuesta.status(200).send("Campo activo añadido");
    } catch (error) {
        console.log(error);
    }
};

export const eliminarUsuario = async (peticion, respuesta) => {
    try {
        await userModel.deleteOne({ name: "Luis", lastname: "Torres" });
        respuesta.status(200).send("Usuario eliminado");
    } catch (error) {
        console.log(error);
    }
};

export const eliminarUsuariosMenoresDe30 = async (peticion, respuesta) => {
    try {
        await userModel.deleteMany({ age: { $lt: 30 } });
        respuesta.status(200).send("Usuarios menores de 30 eliminados");
    } catch (error) {
        console.log(error);
    }
};

