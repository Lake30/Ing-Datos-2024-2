import { Router } from "express";
router.get('/productos', eliminarProductosMenorA50)
router.get('/productos', eliminarProductosMenorA50)
import { obtenerProductosMayorA100, obtenerProductosOrdenadosDesc, añadirCampoEnStock, actualizarStockMayorA500, eliminarProductosMenorA50 } from "../controller/productosController.js";
const router = Router()

router.get('/productos', obtenerProductosMayorA100)
router.get('/productos', obtenerProductosOrdenadosDesc)
router.post('/productos', añadirCampoEnStock)
router.put('/productos', actualizarStockMayorA500)
router.delete('/productos', eliminarProductosMenorA50)

export default router;