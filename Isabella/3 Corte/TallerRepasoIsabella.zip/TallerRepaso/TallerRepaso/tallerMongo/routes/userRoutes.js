import { Router } from "express";
import { crearDatos, obtenerDatos, obtenerUsuarioPorNombre, obtenerUsuariosMayoresDe30, actualizarEdadUsuario, activarUsuariosMayoresDe30, eliminarUsuario, eliminarUsuariosMenoresDe30} from "../controller/userController.js";
const router = Router()

router.get('/usuarios', obtenerDatos)
router.post('/usuarios', crearDatos)
router.get('/usuarios', obtenerUsuarioPorNombre)
router.get('/usuarios', obtenerUsuariosMayoresDe30)
router.put('/usuarios', actualizarEdadUsuario)
router.put('/usuarios', activarUsuariosMayoresDe30)
router.delete('/usuarios', eliminarUsuario)
router.delete('/usuarios', eliminarUsuariosMenoresDe30)

export default router;
