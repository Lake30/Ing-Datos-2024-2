import { productosModel } from "../model/productosModel.js";

export const precioMayorA100 = async () => {
    try {
        const resultado = await productosModel.find({price:{$gt:100}});
        return resultado; 
    } catch (error) {
        console.log(error);
    }
};

