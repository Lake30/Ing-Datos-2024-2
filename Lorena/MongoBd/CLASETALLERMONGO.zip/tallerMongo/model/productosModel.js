import mongoose, { Schema } from "mongoose";

const productosSchema = new Schema({
    name: String,
    price: String,
    category: String
})

export const productosModel = new mongoose.model('Productos', productosSchema)