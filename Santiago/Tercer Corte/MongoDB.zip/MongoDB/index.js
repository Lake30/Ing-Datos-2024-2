
// agregar las rutas para manipular user - son como las funciones

const express=require("express");
const mongoose=require("mongoose");

const app=express();
const PORT=3000;

//Crear el cierpo de las peticiones (Middleware)
app.use(express.json());

// conexión base de datos
mongoose.connect("mongodb://localhost:27017/mongo",{
     useNewURLParser:true,
     useUnifiedTopology: true
}).then(()=>console.log('Se conectó a mongo'))
.catch(err=>console.error('No se concentó a BD error:',err));

//iniciar el servidor
app.listen(PORT,()=>{
    console.log('Servidor ejecutandose sobre el puerto, ${PORT}');
});

const User=require ("./user");

// Registrar un usuario nuevo

app.post("/user", async(req,res)=>{ // req, res es request y respond 
try{
    const user= new User(req.Body); // instanciando una clase, o sea creando un objeto
    await user.save();
    res.status(201).send(user);
}catch (error){
    res.status(400).send(error);
}

});

// consultar usuarios

app.get("/user", async(req,res)=>{
    try{
        const user = await User.find();
        res.status(201).send(user);
    }catch (error){
        res.status(400).send(error);
    }
});

// consultar usuarios por ID

app.get("/user/:id", async(req,res)=>{
    try{
        const user = await User.findByID(req.params.id);
        if(!user)return response.status(404).send();
        res.status(201).send(user);
    }catch (error){
        res.status(400).send(error);
    }
});

// Actualizar usuario por id

app.get("/user/:id", async(req,res)=> {
    try{
        const user = await User.findByIdAndUpdate(req.params.id, req.body, {new:true, runValidators:true});
        if(!user) return response.status(404).send()
    } catch {
        res.status(404).send(error)
}
})

// Eliminar usuario por id

app.get("/user/:id", async(req,res)=> {
    try{
        const user = await User.findByIdAndDelete(req.params.id);
        if(!user) return response.status(404).send()
    } catch {
        res.status(404).send(error)
}
})

// Si se quiere usar un método o lo que uno importaria de una librería, se instala primero en la terminal y luego se usa 

