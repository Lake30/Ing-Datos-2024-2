//modelo para definir la manipulación del módulo de usuario

const mongoose=require("mongoose");

const userSchema=new mongoose.Schema({
    nombre: {
        type:String,  // Tipo de dato
        require:true //Tiene que ser obligatorio
    },
    edad: {
        type:Number,
        require:true
        },
    email: {
        type:String,
        require:true
    }
}); //instancia,   los campos van a ser los datos que van a tener los documentos 

module.exports=mongoose.model("user",userSchema); // se exporta el modulo de mongo con nombre de user, que esta definido como userSchema
//el nombre del modelo es el de la carpeta
