//Por cada modulo se crea un archivo aqui en controller

import {userModel} from"../model/userModel"

export const obtenerDatos= async (peticion,respuesta) => {
    try{
        let usuarios = await userModel.find()
        respuesta.status(200).render("index, {usuarios}")
    } catch (error) {
        console.log(error)
    }
}

export const crearUsuarios = async (peticion,respuesta) => {
    try {
        let data=peticion.body
        //guardar datos
        await userModel.create(data)
        // Se puede hacer que devuelva como respuesta una vista por ejemplo
        let usuarios = await userModel.find()
        respuesta.status(200).render("index, {usuarios}")
    } catch (error) {
        console.log(error)
    }
}