import mondoose, {Schema} from "mongoose";

const userSchema= new Schema({
    // campos que se quiere que tenga la coleccion para los documentos
    name:String,
    lastname:String,
    email:String,
    role:String
})

export const userModel= new mongoose.model("Users", userSchema);