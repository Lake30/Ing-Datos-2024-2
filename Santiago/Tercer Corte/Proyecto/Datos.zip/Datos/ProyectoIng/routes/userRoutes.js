import { Router } from "express"
const router=Router()

router.get('/usuarios', obtenerDatos)
router.post('/usuarios', crearUsuarios)

export default router;