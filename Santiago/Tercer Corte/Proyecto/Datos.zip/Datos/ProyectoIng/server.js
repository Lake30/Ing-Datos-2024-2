import { config } from "dotenv"
import express, { json } from "express"
import path from "path"

import { __dirname } from "./util/__dirname"
import { connectDatabase } from "./config/database"
import { userRoutes } from "./routes/userRoutes"
import exp from "constants"

config()

//Conexion a la base de datos

connectDatabase()
.then(()=>{
    console.log("Conexion a la base de datos exitosa")
})
.catch(()=>{
    console.log("Error al conectar a la base de datos")
    process.exit(1)
});

//configuracion del servidor

const server= express()
const PORT=process.env.PORT

server.use(express.urlencoded({extended:true}))
server.use(express.static("public")) //se utiliza para la interfaz grafica


//configurar el motor de plantillas 

server.set('view engine','ejs') 
server.set('views', path.join(__dirname,"views")); // ** Preguntar, que hace dirname>>?
server.use(json())

// configurar las rutas de acceso

server.use(userRoutes)
// Cuando se traen valores de variables, se ponen comillas inclinadas, como en la siguiente linea
server.listen(PORT,()=> console.log(`Server running en el puerto ${PORT}`))