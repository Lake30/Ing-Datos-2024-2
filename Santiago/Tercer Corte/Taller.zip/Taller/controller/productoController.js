import {productoModel} from"../model/productoModel.js"

export const obtenerDatos= async (peticion,respuesta) => {
    try{
        let productos = await productoModel.find()
        respuesta.status(200).render("index, {productos}")
    } catch (error) {
        console.log(error)
    }
}

export const crearProducto = async (peticion,respuesta) => {
    try {
        let data=peticion.body
        //guardar datos
        await productoModel.create(data)
        // Se puede hacer que devuelva como respuesta una vista por ejemplo
        let productos = await productoModel.find()
        respuesta.status(200).render("index, {productos}")
    } catch (error) {
        console.log(error)
    }
}



