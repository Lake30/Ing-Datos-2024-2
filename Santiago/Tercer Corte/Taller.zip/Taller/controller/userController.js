//Por cada modulo se crea un archivo aqui en controller

import {userModel} from"../model/userModel.js"

export const obtenerDatos= async (peticion,respuesta) => {
    try{
        let usuarios = await userModel.find()
        respuesta.status(200).render("index, {usuarios}")
    } catch (error) {
        console.log(error)
    }
}

export const crearUsuarios = async (peticion,respuesta) => {
    try {
        let data=peticion.body
        //guardar datos
        await userModel.create(data)
        // Se puede hacer que devuelva como respuesta una vista por ejemplo
        let usuarios = await userModel.find()
        respuesta.status(200).render("index, {usuarios}")
    } catch (error) {
        console.log(error)
    }
}

export const obtenerDatosNombre = async (nombreEncontrar,respuesta) => {
    try {
        
        let usuarios = await userModel.findOne({nombre:nombreEncontrar});
        respuesta.status(200).render("index, {usuarios}")
        if (usuarios) {
            console.log("usuario encontrado")
        } else {
            console.log("usuario no encontrado")
        }
    } catch (error) {
        console.log(error)
    }
}

export const obtenerDatosEdad = async (edad,respuesta) => {
    try {
        
        let usuarios = await userModel.findOne({nombre:edad});
        respuesta.status(200).render("index, {usuarios}")
    } catch (error) {
        console.log(error)
    }
}
