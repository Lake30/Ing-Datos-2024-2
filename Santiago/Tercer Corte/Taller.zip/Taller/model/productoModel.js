import mongoose, {Schema} from "mongoose";

const productoSchema= new Schema({
    // campos que se quiere que tenga la coleccion para los documentos
    nombre:String,
    precio:String,
    categoria:String
})

export const productoModel= new mongoose.model("Users", productoSchema);
