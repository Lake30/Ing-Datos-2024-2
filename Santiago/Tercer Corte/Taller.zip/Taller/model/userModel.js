import mongoose, {Schema} from "mongoose";

const userSchema= new Schema({
    // campos que se quiere que tenga la coleccion para los documentos
    nombre:String,
    edad:String,
    email:String
})

export const userModel= new mongoose.model("Users", userSchema);