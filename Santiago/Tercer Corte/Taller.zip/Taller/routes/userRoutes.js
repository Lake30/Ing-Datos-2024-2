import { Router } from "express";
import { crearUsuarios, obtenerDatos, obtenerDatosEdad, obtenerDatosNombre } from "../controller/userController.js";
const router=Router()

router.get('/usuarios', obtenerDatos)
router.post('/usuarios', crearUsuarios)
router.get('/usuarios/name', obtenerDatosNombre)
router.get('/usuarios/name', obtenerDatosEdad)

obtenerDatosNombre("Ana").catch((err) => console.error("El nombre no ha sido encontrado", err));

obtenerDatosEdad("38 años").catch((err) =>console.error("No ha sido encontrado usuario con esa edad"));


export default router;