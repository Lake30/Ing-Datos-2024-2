import { config } from "dotenv"
import express, { json } from "express"
import path from "path"

import { __dirname } from "./util/_dirname.js"
import { connectDatabase } from "./config/database.js"
import  userRoutes  from "./routes/userRoutes.js"
import  productoRoutes  from "./routes/productoRoutes.js"
import exp from "constants"

console.log(__dirname);


config()

//Conexion a la base de datos

connectDatabase()
.then(()=>{
    console.log("Conexion a la base de datos exitosa")
})
.catch(()=>{
    console.log("Error al conectar a la base de datos")
    process.exit(1)
});

//configuracion del servidor

const server= express()
const PORT=process.env.PORT

server.use(express.urlencoded({extended:true}))
server.use(express.static("public")) //se utiliza para la interfaz grafica


// configurar las rutas de acceso

server.use(productoRoutes)
server.use(userRoutes)
// Cuando se traen valores de variables, se ponen comillas inclinadas, como en la siguiente linea
server.listen(PORT,()=> console.log(`Server running en el puerto ${PORT}`))