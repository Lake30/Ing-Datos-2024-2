import { fileURLToPath } from "url";
import {dirname } from "path";
// Get the current file path from import.meta.url
const __filename = fileURLToPath(import.meta.url);
//Configuración de directorio raiz carpeta SRC
const __dirname = dirname(__filename);

export { __dirname};
