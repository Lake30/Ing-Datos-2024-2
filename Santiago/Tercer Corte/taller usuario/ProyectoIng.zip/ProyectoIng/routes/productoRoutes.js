import { Router } from "express";
import { crearProducto, obtenerDatos } from "../controller/productoController";
const router=Router()

router.get('/producto', obtenerDatos)
router.post('/producto', crearProducto)

export default router;