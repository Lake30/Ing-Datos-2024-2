import { Router } from "express";
import { crearUsuarios, obtenerDatos, obtenerDatosEdad, obtenerDatosNombre } from "../controller/userController";
const router=Router()

router.get('/usuarios', obtenerDatos)
router.post('/usuarios', crearUsuarios)
router.get('/usuarios/name', obtenerDatosNombre)
router.get('/usuarios/name', obtenerDatosEdad)

obtenerDatosNombre("Ana").catch.console.error("El nombre no ha sido encontrado");

obtenerDatosEdad("38 años").catch.console.error("No ha sido encontrado usuario con esa edad");


export default router;