import { entradasModel } from "../model/entradasModel.js";

export const registrarEntradas = async (peticion, respuesta) => {
    try {
        const newEntrada = new Object(peticion.body);  
        await productoModel.create(newEntrada);  
        let entradas = await entradasModel.find();  
        respuesta.status(200).render("index", { entradas }); 
    } catch (error) {
        console.log(error);
    }
};


