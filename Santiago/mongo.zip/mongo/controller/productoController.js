import { productoModel } from "../model/productoModel.js";

export const registrarProducto = async (peticion, respuesta) => {
    try {
        const newProducto = new Object(peticion.body);  
        await productoModel.create(newProducto);  
        let productos = await productoModel.find();  
        respuesta.status(200).render("index", { productos }); 
    } catch (error) {
        console.log(error);
    }
};

export const consultarProductosRegistrados = async (peticion, respuesta) => {
    try {
        let productos = await productoModel.find();
        respuesta.status(200).render("index", { productos });
    } catch (error) {
        console.log(error);
    }
};

export const eliminarProducto = async (peticion, respuesta) => {
    try {
        const { idProducto } = peticion.body;  
        await productoModel.findOneAndDelete({ idProducto });  
        let productos = await productoModel.find();  
        respuesta.status(200).render("index", { productos });  
    } catch (error) {
        console.log(error);
    }
};

export const modificarReferenciaProducto = async (peticion, respuesta) => {
    try {
        const newProducto = new Object(peticion.body);  
        await productoModel.findOneAndUpdate({ idProducto: newProducto.idProducto }, { referenciaProducto: newProducto.nuevaReferencia });  
        let productos = await productoModel.find();  
        respuesta.status(200).render("index", { productos });  
    } catch (error) {
        console.log(error);
    }
};

export const modificarPrecioProducto = async (peticion, respuesta) => {
    try {
        const newProducto = new Object(peticion.body);  
        await productoModel.findOneAndUpdate({ idProducto: newProducto.idProducto }, { precioProducto: newProducto.nuevoPrecio }); 
        let productos = await productoModel.find();  
        respuesta.status(200).render("index", { productos }); 
    } catch (error) {
        console.log(error);
    }
};

export const consultarGuitarrasZurdas = async (peticion, respuesta) => {
    try {
        let guitarrasZurdas = await productoModel.find({ referenciaProducto: /zurdas/i }); 
        respuesta.status(200).render("index", { guitarrasZurdas }); 
    } catch (error) {
        console.log(error);
    }
};

export const ordenarPrecioAscendente = async (peticion, respuesta) => {
    try {
        let productosOrdenados = await productoModel.find().sort({ precioProducto: 1 }); 
        respuesta.status(200).render("index", { productosOrdenados }); 
    } catch (error) {
        console.log(error);
    }
};

export const modificarEstadoProducto = async (peticion, respuesta) => {
    try {
        const { idProducto, nuevoEstado } = peticion.body;
        await productoModel.findOneAndUpdate({ idProducto },{ estadoProducto: nuevoEstado });
        let productos = await productoModel.find();
        respuesta.status(200).render("index", { productos });
    } catch (error) {
        console.log(error);
    }
};

export const consultarProductosDisponibles = async (peticion, respuesta) => {
    try {
        let productosDisponibles = await productoModel.find({ estadoProducto: true });
        respuesta.status(200).render("index", { productosDisponibles });
    } catch (error) {
        console.log(error);
    }
};

export const consultarPrecioporID = async (peticion, respuesta) => {
    try {
        const { idProducto } = peticion.body;
        let producto = await productoModel.findOne({ idProducto }, { precioProducto: 1});
        respuesta.status(200).render("index", { producto });
    } catch (error) {
        console.log(error);
    }
};

export const consultarCantidadporID = async (peticion, respuesta) => {
    try {
        const { idProducto } = peticion.body;
        let producto = await productoModel.findOne({ idProducto }, { cantidadProducto: 1 });
        respuesta.status(200).render("index", { producto });
    } catch (error) {
        console.log(error);
    }
};

export const consultarIDporReferencia = async (peticion, respuesta) => {
    try {
        const { referenciaProducto } = peticion.body;
        let producto = await productoModel.findOne({ referenciaProducto }, { idProducto: 1});
        respuesta.status(200).render("index", { producto });
    } catch (error) {
        console.log(error);
    }
};

export const consultarProductosconAccesorios = async (respuesta) => {
    try {
        let productosConAccesorios = await productoModel.find({
            referenciaProducto: /afinador|estuche/i
        });
        respuesta.status(200).render("index", { productosConAccesorios });
    } catch (error) {
        console.log(error);
    }
};





