import { proveedorModel } from "../model/proveedorModel.js";

export const registrarProveedor = async (peticion, respuesta) => {
    try {
        const newProveedor = new proveedorModel(peticion.body);  
        await newProveedor.save();  
        let proveedores = await proveedorModel.find();  
        respuesta.status(200).render("index", { proveedores }); 
    } catch (error) {
        console.log(error);
    }
};

export const consultarProveedores = async (respuesta) => {
    try {
        let proveedores = await proveedorModel.find();  
        respuesta.status(200).render("index", { proveedores }); 
    } catch (error) {
        console.log(error);
    }
};

export const modificarContactoPrincipal = async (peticion, respuesta) => {
    try {
        const { idProveedor, nuevoContacto } = peticion.body;
        await proveedorModel.findOneAndUpdate({ idProveedor },{ contactoPrincipalProveedor: nuevoContacto });
        let proveedores = await proveedorModel.find();  
        respuesta.status(200).render("index", { proveedores });
    } catch (error) {
        console.log(error);
    }
};

export const modificarTelefono = async (peticion, respuesta) => {
    try {
        const { idProveedor, nuevoTelefono } = peticion.body;
        await proveedorModel.findOneAndUpdate({ idProveedor },{ telefonoProveedor: nuevoTelefono });
        let proveedores = await proveedorModel.find();  
        respuesta.status(200).render("index", { proveedores });
    } catch (error) {
        console.log(error);
    }
};

export const eliminarProveedor = async (peticion, respuesta) => {
    try {
        const { idProveedor } = peticion.body;
        await proveedorModel.findOneAndDelete({ idProveedor });
        let proveedores = await proveedorModel.find();  
        respuesta.status(200).render("index", { proveedores });
    } catch (error) {
        console.log(error);
    }
};

export const consultarProveedoresPorPaisOrigen = async (peticion, respuesta) => {
    try {
        const { paisOrigenProveedor } = peticion.body;
        let proveedores = await proveedorModel.find({ paisOrigenProveedor });
        respuesta.status(200).render("index", { proveedores });
    } catch (error) {
        console.log(error);
    }
};

export const modificarEstadoProveedor = async (peticion, respuesta) => {
    try {
        const { idProveedor, nuevoEstado } = peticion.body;
        await proveedorModel.findOneAndUpdate({ idProveedor },{ estadoProveedor: nuevoEstado });
        let proveedores = await proveedorModel.find();  
        respuesta.status(200).render("index", { proveedores });
    } catch (error) {
        console.log(error);
    }
};

export const modificarCorreoProveedor = async (peticion, respuesta) => {
    try {
        const { idProveedor, nuevoCorreo } = peticion.body;
        await proveedorModel.findOneAndUpdate({ idProveedor },{ correoProveedor: nuevoCorreo });
        let proveedores = await proveedorModel.find();  
        respuesta.status(200).render("index", { proveedores });
    } catch (error) {
        console.log(error);
    }
};

export const modificarNombreProveedor = async (peticion, respuesta) => {
    try {
        const { idProveedor, nuevoNombre } = peticion.body;
        await proveedorModel.findOneAndUpdate(
            { idProveedor },
            { nombreProveedor: nuevoNombre }
        );
        let proveedores = await proveedorModel.find();  
        respuesta.status(200).render("index", { proveedores });
    } catch (error) {
        console.log(error);
    }
};

export const consultarTelefonoPorID = async (peticion, respuesta) => {
    try {
        const { idProveedor } = peticion.body;
        let proveedor = await proveedorModel.findOne({ idProveedor }, { telefonoProveedor: 1 });
        respuesta.status(200).render("index", { proveedor });
    } catch (error) {
        console.log(error);
    }
};

export const consultarCorreoPorID = async (peticion, respuesta) => {
    try {
        const { idProveedor } = peticion.body;
        let proveedor = await proveedorModel.findOne({ idProveedor }, { correoProveedor: 1 });
        respuesta.status(200).render("index", { proveedor });
    } catch (error) {
        console.log(error);
    }
};

export const consultarContactoPorID = async (peticion, respuesta) => {
    try {
        const { idProveedor } = peticion.body;
        let proveedor = await proveedorModel.findOne({ idProveedor }, { contactoPrincipalProveedor: 1 });
        respuesta.status(200).render("index", { proveedor });
    } catch (error) {
        console.log(error);
    }
};

export const consultarIDporMarca = async (peticion, respuesta) => {
    try {
        const { marcaProveedor } = peticion.body;
        let proveedor = await proveedorModel.findOne({ marcaProveedor }, { idProveedor: 1 });
        respuesta.status(200).render("index", { proveedor });
    } catch (error) {
        console.log(error);
    }
};

export const consultarContactoPorMarca = async (peticion, respuesta) => {
    try {
        const { marcaProveedor } = peticion.body;
        let proveedor = await proveedorModel.findOne({ marcaProveedor }, { contactoPrincipalProveedor: 1 });
        respuesta.status(200).render("index", { proveedor });
    } catch (error) {
        console.log(error);
    }
};

export const consultarProveedoresActivos = async (peticion, respuesta) => {
    try {
        let proveedoresActivos = await proveedorModel.find({ estadoProveedor: true });
        respuesta.status(200).render("index", { proveedoresActivos });
    } catch (error) {
        console.log(error);
    }
};
