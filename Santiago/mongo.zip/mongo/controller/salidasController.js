import { salidasModel } from "../model/salidasModel.js";

export const registrarSalidas = async (peticion, respuesta) => {
    try {
        const newSalida = new Object(peticion.body);  
        await productoModel.create(newSalida);  
        let salidas = await salidasModel.find();  
        respuesta.status(200).render("index", { salidas }); 
    } catch (error) {
        console.log(error);
    }
};