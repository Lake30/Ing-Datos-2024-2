import { usuarioModel } from "../model/usuarioModel.js";

export const registrarUsuario = async (data, respuesta) => {
    try {
        await usuarioModel.create(data);
        let usuarios = await usuarioModel.find();
        respuesta.status(200).render("index", { usuarios });
    } catch (error) {
        console.log(error);
    }
};

export const consultarUsuarios = async (respuesta) => {
    try {
        let usuarios = await usuarioModel.find();
        respuesta.status(200).render("index", { usuarios });
    } catch (error) {
        console.log(error);
    }
};

export const eliminarUsuarios = async (idUsuario, respuesta) => {
    try {
        await usuarioModel.findOneAndDelete({ idUsuario });
        let usuarios = await usuarioModel.find();
        respuesta.status(200).render("index", { usuarios });
    } catch (error) {
        console.log(error);
    }
};

export const modificarCargoUsuario = async (idUsuario, nuevoCargo, respuesta) => {
    try {
        await usuarioModel.findOneAndUpdate({ idUsuario }, { cargoUsuario: nuevoCargo });
        let usuarios = await usuarioModel.find();
        respuesta.status(200).render("index", { usuarios });
    } catch (error) {
        console.log(error);
    }
};

export const modificarTelefonoUsuario = async (idUsuario, nuevoTelefono, respuesta) => {
    try {
        await usuarioModel.findOneAndUpdate({ idUsuario }, { telefonoUsuario: nuevoTelefono });
        let usuarios = await usuarioModel.find();
        respuesta.status(200).render("index", { usuarios });
    } catch (error) {
        console.log(error);
    }
};

export const modificarCorreoUsuario = async (idUsuario, nuevoCorreo, respuesta) => {
    try {
        await usuarioModel.findOneAndUpdate({ idUsuario }, { correoUsuario: nuevoCorreo });
        let usuarios = await usuarioModel.find();
        respuesta.status(200).render("index", { usuarios });
    } catch (error) {
        console.log(error);
    }
};

export const modificarEstadoUsuario = async (idUsuario, nuevoEstado, respuesta) => {
    try {
        await usuarioModel.findOneAndUpdate({ idUsuario }, { estadoUsuario: nuevoEstado });
        let usuarios = await usuarioModel.find();
        respuesta.status(200).render("index", { usuarios });
    } catch (error) {
        console.log(error);
    }
};

export const modificarContrasena = async (idUsuario, nuevaContrasena, respuesta) => {
    try {
        await usuarioModel.findOneAndUpdate({ idUsuario }, { contrasenaUsuario: nuevaContrasena });
        let usuarios = await usuarioModel.find();
        respuesta.status(200).render("index", { usuarios });
    } catch (error) {
        console.log(error);
    }
};

export const consultarUsuariosActivos = async (respuesta) => {
    try {
        let usuarios = await usuarioModel.find({ estadoUsuario: true });
        respuesta.status(200).render("index", { usuarios });
    } catch (error) {
        console.log(error);
    }
};

export const consultarIDporCargo = async (cargoUsuario, respuesta) => {
    try {
        let usuarios = await usuarioModel.find({ cargoUsuario });
        respuesta.status(200).render("index", { usuarios });
    } catch (error) {
        console.log(error);
    }
};

export const consultarIDporCedula = async (cedulaUsuario, respuesta) => {
    try {
        let usuario = await usuarioModel.findOne({ cedulaUsuario });
        respuesta.status(200).render("index", { usuario });
    } catch (error) {
        console.log(error);
    }
};

export const consultarTelefonoporID = async (idUsuario, respuesta) => {
    try {
        let usuario = await usuarioModel.findOne({ idUsuario });
        respuesta.status(200).render("index", { usuario });
    } catch (error) {
        console.log(error);
    }
};

export const consultarCorreoporID = async (idUsuario, respuesta) => {
    try {
        let usuario = await usuarioModel.findOne({ idUsuario });
        respuesta.status(200).render("index", { usuario });
    } catch (error) {
        console.log(error);
    }
};

export const consultarIDporNombre = async (nombreUsuario, respuesta) => {
    try {
        let usuarios = await usuarioModel.find({ nombreUsuario });
        respuesta.status(200).render("index", { usuarios });
    } catch (error) {
        console.log(error);
    }
};

export const consultarNacimientoporNombre = async (nombreUsuario, respuesta) => {
    try {
        let usuario = await usuarioModel.findOne({ nombreUsuario });
        respuesta.status(200).render("index", { usuario });
    } catch (error) {
        console.log(error);
    }
};
