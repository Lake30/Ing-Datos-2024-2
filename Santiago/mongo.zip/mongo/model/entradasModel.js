import mongoose, { Schema } from "mongoose";

const entradasSchema = new Schema({
    idEntrada: Number,
    idProveedorFK: String,
    fechaEntrada: Date,
    cantidadEntrada: Number,
    idProductoFK: String
})

export const entradasModel = new mongoose.model('Entradas', entradasSchema) 