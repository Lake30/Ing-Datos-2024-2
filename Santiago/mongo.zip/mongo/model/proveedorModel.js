import mongoose, { Schema } from "mongoose";

const proveedorSchema = new Schema({
    idProveedor: Number,
    nombreProveedor: String,
    contactoPrincipalProveedor: String,
    telefonoProveedor: String,
    correoProveedor: String,
    paisOrigenProveedor: String,
    estadoProveedor: Boolean
})

export const proveedorModel = new mongoose.model('Proveedor', proveedorSchema)