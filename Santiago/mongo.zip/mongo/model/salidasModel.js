import mongoose, { Schema } from "mongoose";

const salidasSchema = new Schema({
    idSalida: Number,
    idUsuarioFK: String,
    fechaSalida: Date,
    idProductoFK: String,
    cantidadEntrada: Number

})

export const salidasModel = new mongoose.model('Salidas', salidasSchema)