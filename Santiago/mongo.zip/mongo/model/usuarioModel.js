import mongoose, { Schema } from "mongoose";

const usuarioSchema = new Schema({
    idUsuario: Number,
    nombreUsuario: String,
    apellidoUsuario: String,
    cargoUsuario: String,
    contrasenaUsuario: String,
    cedulaUsuario: Number,
    direccionUsuario: String,
    telefonoUsuario: String,
    correoUsuario: String,
    fechaNacimientoUsuario: Date,
    estadoUsuario: Boolean
})

export const usuarioModel = new mongoose.model('Usuario', usuarioSchema)
