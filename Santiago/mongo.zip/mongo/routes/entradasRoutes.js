import { Router } from "express";
import { registrarEntradas } from "../controller/entradasController.js";
const router = Router()

router.get('/Entradas', registrarEntradas);

export default router;