import entradasRoutes from "./entradasRoutes.js";
import productoRoutes from "./productoRoutes.js";
import proveedorRoutes from "./proveedorRoutes.js";
import salidasRoutes from "./salidasRoutes.js";
import usuarioRoutes from "./usuarioRoute.js";

export default [
    entradasRoutes,
    productoRoutes,
    proveedorRoutes,
    salidasRoutes,
    usuarioRoutes
];
