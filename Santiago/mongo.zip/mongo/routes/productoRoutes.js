import { Router } from "express";
import { consultarCantidadporID, consultarGuitarrasZurdas, consultarIDporReferencia, consultarPrecioporID, consultarProductosconAccesorios, consultarProductosDisponibles, consultarProductosRegistrados, eliminarProducto, modificarEstadoProducto, modificarPrecioProducto, modificarReferenciaProducto, ordenarPrecioAscendente, registrarProducto } from "../controller/productoController.js";

const router = Router()

router.get('/Producto', registrarProducto);
router.get('/Producto', consultarProductosRegistrados);
router.get('/Producto', eliminarProducto);
router.get('/Producto', modificarReferenciaProducto);
router.get('/Producto', modificarPrecioProducto);
router.get('/Producto', consultarGuitarrasZurdas);
router.get('/Producto', ordenarPrecioAscendente);
router.get('/Producto', modificarEstadoProducto);
router.get('/Producto', consultarProductosDisponibles);
router.get('/Producto', consultarPrecioporID);
router.get('/Producto', consultarCantidadporID);
router.get('/Producto', consultarIDporReferencia);
router.get('/Producto', consultarProductosconAccesorios);

export default router;