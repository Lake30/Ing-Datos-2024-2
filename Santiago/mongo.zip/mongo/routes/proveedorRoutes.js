import { Router } from "express";
import { consultarContactoPorID, consultarProveedores, consultarContactoPorMarca, consultarCorreoPorID, consultarIDporMarca, consultarProveedoresActivos, consultarProveedoresPorPaisOrigen, consultarTelefonoPorID, eliminarProveedor, modificarContactoPrincipal, modificarCorreoProveedor, modificarEstadoProveedor, modificarNombreProveedor, modificarTelefono, registrarProveedor } from "../controller/proveedorController.js";

const router = Router()

router.post('/Proveedor', registrarProveedor);
router.get('/Proveedor', consultarProveedores);
router.put('/Proveedor', modificarContactoPrincipal);
router.put('/Proveedor', modificarTelefono);
router.delete('/Proveedor', eliminarProveedor);
router.get('/Proveedores', consultarProveedoresPorPaisOrigen);
router.put('/Proveedor', modificarEstadoProveedor);
router.put('/Proveedor', modificarCorreoProveedor);
router.put('/Proveedor', modificarNombreProveedor);
router.get('/Proveedor', consultarTelefonoPorID);
router.get('/Proveedor', consultarCorreoPorID);
router.get('/Proveedor', consultarContactoPorID);
router.get('/Proveedor', consultarIDporMarca);
router.get('/Proveedor', consultarContactoPorMarca);
router.get('/Proveedor', consultarProveedoresActivos);


export default router;