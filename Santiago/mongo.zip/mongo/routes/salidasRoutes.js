import { Router } from "express";
import { registrarSalidas } from "../controller/salidasController.js";

const router = Router()

router.get('/Salidas', registrarSalidas);

export default router;