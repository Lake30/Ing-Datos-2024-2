import { Router } from "express";
import { registrarUsuario, consultarUsuarios, eliminarUsuarios, modificarCargoUsuario, modificarTelefonoUsuario, modificarCorreoUsuario, modificarEstadoUsuario, modificarContrasena, consultarUsuariosActivos, consultarIDporCargo, consultarIDporCedula, consultarTelefonoporID, consultarCorreoporID, consultarIDporNombre, consultarNacimientoporNombre } from "../controller/usuarioController.js";
const router = Router()

router.post('/Usuario', registrarUsuario)
router.get('/Usuario', consultarUsuarios)
router.delete('/Usuario', eliminarUsuarios)
router.put('/Usuario', modificarCargoUsuario)
router.put('/Usuario', modificarTelefonoUsuario)
router.put('/Usuario', modificarCorreoUsuario)
router.put('/Usuario', modificarEstadoUsuario)
router.put('/Usuario', modificarContrasena)
router.get('/Usuario', consultarUsuariosActivos)
router.get('/Usuario', consultarIDporCargo)
router.get('/Usuario', consultarIDporCedula)
router.get('/Usuario', consultarTelefonoporID)
router.get('/Usuario', consultarCorreoporID)
router.get('/Usuario', consultarIDporNombre)
router.get('/Usuario', consultarNacimientoporNombre)

export default router;
